package net.sf.RecordEditor.test.cobol;

import static org.junit.Assert.*;

import org.junit.Test;

import net.sf.JRecord.External.CopybookLoaderFactory;
import net.sf.RecordEditor.re.util.csv.SchemaAnalyser;
import net.sf.cb2xml.def.Cb2xmlConstants;

public class TstCopybookAnalysisCobol {
	
	private final static String[] DTAR020 = {
			"000800    01  DTAR020.",
			"000900        03  DTAR020-KCODE-STORE-KEY.",
			"001000            05 DTAR020-KEYCODE-NO      PIC X(08).",
			"001100            05 DTAR020-STORE-NO        PIC S9(03)   COMP-3.",
			"001200        03  DTAR020-DATE               PIC S9(07)   COMP-3.",
			"001300        03  DTAR020-DEPT-NO            PIC S9(03)   COMP-3.",
	};
	
	private final static String[] ADJ_COL_80 = {
			"001100            05 DTAR025-STORE-NO                       PIC S9(03)   COMP-3.         ",
			"001200        03  DTAR025-DATE                          PIC S9(07)   COMP-3.\n" 
	};
	
	private final static String[] ADJ_COL_GT_80 = {
			"001100            05 DTAR025-STORE-NO                         PIC S9(03)   COMP-3.         ",
			"001200        03  DTAR025-DATE                          PIC S9(07)   COMP-3.\n" 
	};
	
	
	private final static String[] ADJ_FREE_FORMAT = {
			"            05 DTAR025-STORE-NO                               PIC S9(03)   COMP-3.         \n",
			"        03  DTAR025-DATE                                PIC S9(07)   COMP-3.\n" ,
	};

	@Test
	public void testStdColumns() {
		tstCopybook(DTAR020, "\n", Cb2xmlConstants.USE_STANDARD_COLUMNS);
		tstCopybook(DTAR020, "\r\n", Cb2xmlConstants.USE_STANDARD_COLUMNS);
		String[] cpy = new String[DTAR020.length];
		
		for (int i = 0; i < DTAR020.length; i++) {
			StringBuilder b = new StringBuilder(80);
			b.append(DTAR020[i]);
			for (int j = b.length(); j< 80; j++) {
				b.append(j < 73 ? ' ' : '1');
			}
			cpy[i] = b.toString();
		}
		tstCopybook(cpy, "\n", Cb2xmlConstants.USE_STANDARD_COLUMNS);
		tstCopybook(cpy, "\r\n", Cb2xmlConstants.USE_STANDARD_COLUMNS);
	};

	@Test
	public void testColGt80() {
		String[] cpy = DTAR020.clone();
		
		cpy[3] = ADJ_COL_GT_80[0];
		cpy[4] = ADJ_COL_GT_80[1];
		
		tstCopybook(cpy, "\n", Cb2xmlConstants.USE_LONG_LINE);
		tstCopybook(cpy, "\r\n", Cb2xmlConstants.USE_LONG_LINE);
	}

	@Test
	public void testCol80() {
		String[] cpy = DTAR020.clone();
		
		cpy[3] = ADJ_COL_80[0];
		cpy[4] = ADJ_COL_80[1];
		
		tstCopybook(cpy, "\n", Cb2xmlConstants.USE_COLS_6_TO_80);
		tstCopybook(cpy, "\r\n", Cb2xmlConstants.USE_COLS_6_TO_80);
	}
	
	@Test
	public void testFreeForm() {
		String[] cpy  = new String[DTAR020.length];
		String[] cpy1 = new String[DTAR020.length];
		
		for (int i = 0; i < DTAR020.length; i++) {
			cpy[i]  = DTAR020[i].substring(6);
			cpy1[i] = DTAR020[i].substring(8);
		}
		tstCopybook(cpy, "\n",   Cb2xmlConstants.FREE_FORMAT);
		tstCopybook(cpy, "\r\n", Cb2xmlConstants.FREE_FORMAT);
		tstCopybook(cpy1, "\n",  Cb2xmlConstants.FREE_FORMAT);
		
		cpy[3] = ADJ_FREE_FORMAT[0];
		cpy[4] = ADJ_FREE_FORMAT[1];
		
		tstCopybook(cpy, "\n",   Cb2xmlConstants.FREE_FORMAT);
		tstCopybook(cpy, "\r\n", Cb2xmlConstants.FREE_FORMAT);
	}
	
	
	private void tstCopybook(String[] copyLines, String eol, int expectedCopybookFormat) {
		StringBuilder b = new StringBuilder(500);
		for (String l : copyLines) {
			b.append(l).append(eol);
		}
		
		SchemaAnalyser sa = new SchemaAnalyser("cpy.xxx", b.toString());
		
		assertEquals(CopybookLoaderFactory.COBOL_LOADER, sa.schemaType());
		assertEquals(expectedCopybookFormat, sa.cobolCopybookFormat());
	}
}
