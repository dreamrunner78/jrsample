package net.sf.RecordEditor.test.fileStore;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import net.sf.JRecord.Details.LayoutDetail;
import net.sf.JRecord.External.RecordEditorXmlLoader;

public class DeleteColumnHelper {

	
	
	public LayoutDetail genLayout(int fileStructure, int[] trans) throws IOException {
		int[] def = {0,1,2,3};
		String[] cols = {
				"				<FIELD 	NAME=\"aa\" 	DESCRIPTION=\"aa\" 	TYPE=\"Char\"/>",
				"				<FIELD 	NAME=\"bb\" 	DESCRIPTION=\"bb\" 	TYPE=\"Char\"/>",
				"				<FIELD 	NAME=\"cc\" 	DESCRIPTION=\"cc\" 	TYPE=\"Char\"/>",
				"				<FIELD 	NAME=\"dd\" 	DESCRIPTION=\"dd\" 	TYPE=\"Char\"/>",
		};
//		"				<FIELD 	NAME=\"aa\" 	DESCRIPTION=\"aa\" 	POSITION=\"1\" 	TYPE=\"Char\"/>",
//		"				<FIELD 	NAME=\"bb\" 	DESCRIPTION=\"bb\" 	POSITION=\"2\" 	TYPE=\"Char\"/>",
//		"				<FIELD 	NAME=\"cc\" 	DESCRIPTION=\"cc\" 	POSITION=\"3\" 	TYPE=\"Char\"/>",
//		"				<FIELD 	NAME=\"dd\" 	DESCRIPTION=\"dd\" 	POSITION=\"4\" 	TYPE=\"Char\"/>",
		StringBuilder b = new StringBuilder(
			  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
			+ "<RECORD 	RECORDNAME=\"aaa\" 	COPYBOOK=\"aaa\" 	DELIMITER=\",\" 	FONTNAME=\"cp1252\" 	FILESTRUCTURE=\"" + fileStructure + "\" 	STYLE=\"0\" 	RECORDTYPE=\"GroupOfRecords\" 	LIST=\"Y\" 	QUOTE=\"\" 	RecSep=\"default\">"
			+ "	<RECORDS>"
			+ "		<RECORD 	RECORDNAME=\"RecAaa\" 	COPYBOOK=\"aaa_RecAaa\" 	DELIMITER=\",\" 	FONTNAME=\"cp1252\" 	FILESTRUCTURE=\"" + fileStructure + "\" 	STYLE=\"0\" 	RECORDTYPE=\"Delimited\" 	LIST=\"N\" 	QUOTE=\"\" 	RecSep=\"default\">"
			+ "			<FIELDS>");
			
		if (trans == null) {
			trans = def;
		}
		for (int i = 0; i < trans.length; i++) {
			b.append(cols[trans[i]]);
		}
		b.append(
			  "			</FIELDS>"
			+ "		</RECORD>"
			+ "	</RECORDS>"
			+ "</RECORD>");
		RecordEditorXmlLoader loader = new RecordEditorXmlLoader();
		
		return loader.loadCopyBook(new ByteArrayInputStream(b.toString().getBytes()), "Csv").asLayoutDetail();
	}

	public static interface ILineSource {
		boolean next();
		int fieldCount();
		int field(int idx);
		String toLine();
		void reset();
	}
	
	public static class TransSource extends BaseSource {
		private final ILineSource base;
		private final int[] trans;
		
		
		public TransSource(ILineSource iLineSource, int[] trans) {
			super();
			base = iLineSource;
			this.trans = trans;
		}


		public boolean next() {
			return base.next();
		}
		
		
		@Override
		public int fieldCount() {
			return trans.length;
		}


		public int field(int idx) {
			return base.field(trans[idx]);
		}


		public void reset() {
			base.reset();
		}
	}
	
	public static class StdSource extends BaseSource {
		int last, curr=0;
		final int fieldCount;

		public StdSource(int last, int fieldCount) {
			super();
			this.last = last;
			this.fieldCount = fieldCount;
		}

		@Override
		public boolean next() {
			curr += 1;
			return curr <= last;
		}

		@Override
		public int fieldCount() {
			return fieldCount;
		}

		@Override
		public int field(int idx) {
			return curr * 10 + idx;
		}

		@Override
		public void reset() {
			curr = 0;
		}
	}
	
	private abstract static class BaseSource implements ILineSource {
		
		public String toLine() {
			StringBuilder b = new StringBuilder();
			b.append(this.field(0));
			for (int i = 1; i < fieldCount(); i++) {
				b.append(",").append(this.field(i));
			}
			return b.toString();
		}
	}

}
