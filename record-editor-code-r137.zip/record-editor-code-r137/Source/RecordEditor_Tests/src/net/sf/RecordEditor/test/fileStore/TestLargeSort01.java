package net.sf.RecordEditor.test.fileStore;

import java.util.Random;

import junit.framework.TestCase;
import net.sf.JRecord.Common.Constants;
import net.sf.JRecord.Details.AbstractLine;
import net.sf.JRecord.Details.LayoutDetail;
import net.sf.JRecord.Details.Line;
import net.sf.JRecord.Details.LineCompare;
import net.sf.JRecord.External.RecordEditorXmlLoader;
import net.sf.RecordEditor.utils.fileStorage.DataStoreLarge;
import net.sf.RecordEditor.utils.fileStorage.FileDetails;

public class TestLargeSort01 extends TestCase {

	private static String
		xml = "<?xml version=\"1.0\" ?>\n"
			+ "<RECORD RECORDNAME=\"CSV\" COPYBOOK=\"\" DELIMITER=\",\" DESCRIPTION=\"s\"\n"
			+ "	FILESTRUCTURE=\"" + Constants.IO_NAME_1ST_LINE +"\" STYLE=\"0\" RECORDTYPE=\"Delimited\"\n"
			+ "	LIST=\"Y\" QUOTE=\"\" RecSep=\"default\">"
			+ "	<FIELDS>"
			+ "		<FIELD NAME=\"Field1\" POSITION=\"1\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field2\" POSITION=\"2\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field3\" POSITION=\"3\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field4\" POSITION=\"4\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field5\" POSITION=\"5\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field6\" POSITION=\"6\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field7\" POSITION=\"7\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field8\" POSITION=\"8\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field9\" POSITION=\"9\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field10\" POSITION=\"10\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field11\" POSITION=\"11\" TYPE=\"Char\"/>"
			+ "	</FIELDS>"
			+ "</RECORD>";

	public void testSort01() throws Exception {
		tst(500, 2000, 1000, 32000, 20000 );
	}
	

	public void testSort02() throws Exception {
		tst(500, 8000, 2000, 128000, 80000 );
	}
	

	public void testSort03() throws Exception {
		tst(500, 80000, 20000, 12800000,  160000 );
	}
	
	public void tst(
			int recLen, int chunkSize, 
			int sortchunkSize, int sortBlockSize, int numLines) throws Exception {
		LayoutDetail layout = (LayoutDetail) RecordEditorXmlLoader.getExternalRecord(xml, "csv").asLayoutDetail();
		
		FileDetails fd = new FileDetails(
				layout, FileDetails.VARIABLE_LENGTH, recLen, chunkSize, sortchunkSize, sortBlockSize, null);

//		LayoutDetail recordLayout, int type, int recLen, 
//		int chunkSize, int sortchunkSize, int sortBlockSize,
//		IChunkLengthChangedListner chunkLengthChangeListner) {

		DataStoreLarge ds = new DataStoreLarge(fd);
		
		ds.setRecentSizeTest(-1);
		createData(layout, ds, numLines);
		
		LineCompare c = new LineCompare(layout, 0, new int[] {2}, new boolean[] {false});
		ds.sort(c);
		
		System.out.println(" ----------------- Done ------------------");

		boolean ok = true;
		AbstractLine last, line = ds.getNewLineRE(0);
		int size = ds.size();
		int count = 0;
		StringBuffer b = new StringBuffer();
		for (int i = 1; i < size; i++ ) {
			last = line;
			line = ds.getNewLineRE(i);
			if (c.compare(last, line) > 0) {
				b.append("\t* " + i + "> " + last.getField(0, 2) + " < > " + line.getField(0, 2) + '\t');
				ok = false;
				
				if (count++ > 4) {
					b.append("\n");
					count = 0;
				}
			}
		}
		System.out.println(b);
		
		
		String s = b.length() < 1000 ? b.toString() : b.substring(0, 1000); 
	
		assertTrue(s, ok);
	}

	/**
	 * @param layout
	 * @param ds
	 */
	public static void createData(LayoutDetail layout, DataStoreLarge ds, int numLines) {
		StringBuilder b = new StringBuilder(200);
		int rowCount = 11;
		String pref = "field";
		Random  r = new Random(123);
		int size = 0;
		Line line = new Line(layout);
		
		for (int i = 0; i < numLines; i++) {
			String sep = "";
			b.setLength(0);
			for (int j = 1; j <= rowCount; j++) {
				b.append(sep);
				
				if (j == 1) {
					b.append(r.nextInt(30));
				} else if (j < 4) {
					b.append(r.nextInt());
				} else if (j == 4 || j == 6|| j == 8 || j == 10) {
					b.append(r.nextInt())
					 .append("     1111     ")
					 .append(r.nextInt(30))
					 .append("       5555555        ")
					 .append(r.nextInt(30))
					 .append("     1111     ")
					 .append(r.nextLong());
				} else {
					b.append(r.nextLong());
				}
				sep = ",";
			}
			line.setData(b.toString());
			ds.add(line);
			size += b.length() + 1;
		}

		System.out.println("-> " + size);
	}

}
