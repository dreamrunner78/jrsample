package net.sf.RecordEditor.test.jrecord;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;

import com.zbluesoftware.java.bm.IZDateFormat;
import com.zbluesoftware.java.bm.ZDateFormat;

import junit.framework.TestCase;
import net.sf.RecordEditor.re.jrecord.format.ZDateFormatCYMD;

public class TstZDateFormats extends TestCase {

	private static DateData[] dates = {
			new DateData(1999, 02, 11),
			new DateData(2000, 01, 01),
			new DateData(2000, 01, 02),
			new DateData(2001, 02, 02),
			new DateData(2002, 03, 04),
			new DateData(2011, 12, 12),
			new DateData(2014, 12, 16),
			new DateData(2017, 02, 18),
	};
	
	public void test01() throws ParseException {
		DateFormats fmt = new DateFormats();
		for (DateData dd : dates) {
			check(fmt.cyymmddFmt, dd.date, dd.cyymmdd);
			check(fmt.yymmddFmt, dd.date, dd.yymmdd);
			check(fmt.yyyymmddFmt, dd.date, dd.yyyymmdd);
			check(fmt.ddmmyyyyFmt, dd.date, dd.ddmmyyyy);
			check(fmt.ddmmyyFmt, dd.date, dd.ddmmyy);
			check(fmt.mmddyyyyFmt, dd.date, dd.mmddyyyy);
		}
	}
	
	private void check(IZDateFormat df, Date d, int di) throws ParseException {
		String ds = Integer.toString(di);
		assertEquals(d, df.parse(ds));
		assertEquals(di, Integer.parseInt(df.format(d)));
	}
	
	private static class DateData {
		public final Date date;
		public final int yymmdd, yyyymmdd, cyymmdd, ddmmyy, ddmmyyyy, mmddyyyy;
		public final String ddStr, mmStr, dd2Str, mm2Str, yy2Str, yyyyStr, MthStr;


		public DateData(int yyyy, int mm, int dd) {
			String[] months = {
					"Jan", "Feb", "Mar", "Apr",
					"May", "Jun", "Jul", "Aug",
					"Sep", "Oct", "Nov", "Dec"
			};
			int yy = yyyy % 100;
			
			this.ddStr = Integer.toString(dd);
			this.mmStr = Integer.toString(mm);
			String yyStr = Integer.toString(yy);
			this.yyyyStr = Integer.toString(yyyy);
			
			this.dd2Str = ddStr.length() == 1 ? "0" + ddStr : ddStr;
			this.mm2Str = mmStr.length() == 1 ? "0" + mmStr : mmStr;
			this.yy2Str = yyStr.length() == 1 ? "0" + yyStr : yyStr;
			
			this.date = new Date(yyyy -1900, mm-1, dd);
			this.yyyymmdd = yyyy * 10000 + mm * 100 + dd;
			
			this.yymmdd = yyyymmdd % 1000000;
			this.cyymmdd = yyyymmdd - 19000000;
			

			this.ddmmyyyy = yyyy + mm * 10000 + dd * 1000000;
			this.ddmmyy = yy + mm * 100 + dd * 10000;
			
			this.mmddyyyy = yyyy  + mm * 1000000 + dd * 10000;
			
			this.MthStr = months[mm-1];
		}
	}
	
	private static class DateFormats {
		IZDateFormat
				cyymmddFmt = new ZDateFormatCYMD(),
				yyyymmddFmt = new ZDateFormat("yyyyMMdd"),
				yymmddFmt = new ZDateFormat("yyMMdd"),
				ddmmyyyyFmt = new ZDateFormat("ddMMyyyy"),
				ddmmyyFmt = new ZDateFormat("ddMMyy"),
				mmddyyyyFmt = new ZDateFormat("MMddyyyy");
	}
}
