/*
 * @Author Bruce Martin
 * Created on 17/01/2007
 *
 * Purpose:
 */
package net.sf.RecordEditor.test;

import junit.framework.TestCase;
import net.sf.JRecord.Common.Conversion;
import net.sf.JRecord.Details.LayoutDetail;
import net.sf.JRecord.Details.Line;
import net.sf.JRecord.IO.LineIOProvider;
import net.sf.RecordEditor.re.file.FilePosition;
import net.sf.RecordEditor.re.file.FileView;
import net.sf.RecordEditor.re.file.filter.Compare;
import net.sf.RecordEditor.utils.CopyBookDbReader;
import net.sf.RecordEditor.utils.common.Common;

/**
 *
 *
 * @author Bruce Martin
 *
 */
public class TstReplace extends TestCase {
	private int dbIdx = TstConstants.DB_INDEX;

	private CopyBookDbReader copybookInt = new CopyBookDbReader();
    private static LayoutDetail poCopyBook = null;
    private final String poCopybookName = "ams PO Download";
    private final String    find = "00004";
    private final String replace = "11234";



	private FileView poFileRep;

    private final String[] textLines = {
            "H1453570000004338000000233863040929        00  290 0501030501075966        OPTIONS PLCFT",
            "D100044000000000011840000000000000000 45872078000000045440000044       2117093        45872078       MTH5033H DUSTY PINK L/S FANCY CREW C'MERE CARDIGAN",
            "S1501500000001501900000003503300000001333720780001503700000001505200000001505500000001506000000002507000000001507400000001",
            "S1507800000001508100000001508500000001509000000001509100000001509300000001509500000001512900000001514400000001516500000001",
            "S1530300000001516900000001517000000001517100000001517700000001501600000001508900000002513600000001501100000001504600000001",
            "S1514500000001509600000002515400000001516200000001516300000001516400000001519200000001515000000001517500000001    00000000",
            "H1453580000004338000000233872040929        00  290 0501030501075965        OPTIONS PLCFT",
            "D100014000000000011984000000000000000 43372078000000045440000014       2117152        45872078       MTH5033H DUSTY PINK L/S FANCY CREW C'MERE CARDIGAN",
            "S1503600000001504300000001504500000001505700000001506500000001506900000001507600000001507900000001509400000001512800000001",
            "S1515100000001518000000001507200000001517300000001    00000000    00000000    00000000    00000000    00000000    00000000",
            "H1453590000004468000000255906040929        00  290 0501030501075966        OPTIONS PLCFT",
            "D100029000000000010120000000000000000 45874751000000040900000029       2117337        45872078       MTH5030H BLK L/S VLVT RIBBON SCOOP C'MERE W/BROOCH",
            "S1501500000001501900000002503700000002353347510001507000000001507800000001509300000001509500000001512900000001514400000001",
            "S1516500000001517000000001517100000001501600000002508900000002513600000001501100000001504600000001509600000001515400000001",
            "S1516200000001516300000001516400000001519200000001517500000001    00000000    00000000    00000000    00000000    00000000",
            "H1453600000004448290908      040929        00  290 0501030501075967        OPTIONS PLCFT",
            "D100014000000000000000029440800000000 45874751000000040900000014       2117347        35874751       MTH5030H BLK L/S VLVT RIBBON SCOOP C'MERE W/BROOCH",
            "S1508300000001513300000001515500000001358447510001516600000001516700000001504900000001513900000001500200000001502700000001",
            "S1503800000001514000000001517400000001518400000001    00000000    00000000    00000000    00000000    00000000    00000000",
            "H1453610000004228000000292210040929        00  290 0501030501075965        OPTIONS PLCFT",
            "D100012000000000010256000000000000000 35874751000000040900000012       2117354        35874751       MTH5030H BLK L/S VLVT RIBBON SCOOP C'MERE W/BROOCH",
            "S1503600000001504300000001504500000001353347510001506900000001507600000001509400000001512800000001515100000001518000000001",
            "S1507200000001517300000001    00000000    00000000    00000000    00000000    00000000    00000000    00000000    00000000",
            "H1453620000005220000000211984040929        00  200 0501030501075965        LADIES KNICFT",
            "D100011000000000005848000000000000000 31191697000000027260000011       2327928        35891697       SKY BLUE SKP02 L/WEIGHT PONCHO",
            "S1503600000001504300000001504500000001505700000001506500000001506900000001507600000001509400000001512800000001515100000001",
            "S1518000000001    00000000    00000000    00000000    00000000    00000000    00000000    00000000    00000000    00000000",
            "D100011000000000005848000000000000000 33391826000000027260000011       2327931        35891826       DUSTY PINK SKP02 L/WEIGHT PONCHO",
            "S1503600000001504300000001504500000001505700000001506500000001506900000001507600000001509400000001512800000001515100000001",
            "S1518000000001    00000000    00000000    00000000    00000000    00000000    00000000    00000000    00000000    00000000                             "
    };
    private final String[] result1  = {
        "H1453570011234338000000233863040929        00  290 0501030501075966        OPTIONS PLCFT",
        "D100044000000000011840000000000000000 45872078000000045440000044       2117093        45872078       MTH5033H DUSTY PINK L/S FANCY CREW C'MERE CARDIGAN",
        "S1501500000001501900000003503300000001333720780001503700000001505200000001505500000001506000000002507000000001507400000001",
        "S1507800000001508100000001508500000001509000000001509100000001509300000001509500000001512900000001514400000001516500000001",
        "S1530300000001516900000001517000000001517100000001517700000001501600000001508900000002513600000001501100000001504600000001",
        "S1514500000001509600000002515400000001516200000001516300000001516400000001519200000001515000000001517500000001    00000000",
        "H1453580000004338000000233872040929        00  290 0501030501075965        OPTIONS PLCFT",
        "D100014000000000011984000000000000000 43372078000000045440000014       2117152        45872078       MTH5033H DUSTY PINK L/S FANCY CREW C'MERE CARDIGAN",
        "S1503600000001504300000001504500000001505700000001506500000001506900000001507600000001507900000001509400000001512800000001",
        "S1515100000001518000000001507200000001517300000001    00000000    00000000    00000000    00000000    00000000    00000000",
        "H1453590011234468000000255906040929        00  290 0501030501075966        OPTIONS PLCFT",
        "D100029000000000010120000000000000000 45874751000000040900000029       2117337        45872078       MTH5030H BLK L/S VLVT RIBBON SCOOP C'MERE W/BROOCH",
        "S1501500000001501900000002503700000002353347510001507000000001507800000001509300000001509500000001512900000001514400000001",
        "S1516500000001517000000001517100000001501600000002508900000002513600000001501100000001504600000001509600000001515400000001",
        "S1516200000001516300000001516400000001519200000001517500000001    00000000    00000000    00000000    00000000    00000000",
        "H1453600000004448290908      040929        00  290 0501030501075967        OPTIONS PLCFT",
        "D100014000000000000000029440800000000 45874751000000040900000014       2117347        35874751       MTH5030H BLK L/S VLVT RIBBON SCOOP C'MERE W/BROOCH"
    };
    private final String[] result2  = {
            "H1453570011234338000000233863040929        00  290 0501030501075966        OPTIONS PLCFT",
            "D100044000000000011840000000000000000 45872078000000045440000044       2117093        45872078       MTH5033H DUSTY PINK L/S FANCY CREW C'MERE CARDIGAN",
            "S1501500000001501900000003503300000001333720780001503700000001505200000001505500000001506000000002507000000001507400000001",
            "S1507800000001508100000001508500000001509000000001509100000001509300000001509500000001512900000001514400000001516500000001",
            "S1530300000001516900000001517000000001517100000001517700000001501600000001508900000002513600000001501100000001504600000001",
            "S1514500000001509600000002515400000001516200000001516300000001516400000001519200000001515000000001517500000001    00000000",
            "H1453580011234338000000233872040929        00  290 0501030501075965        OPTIONS PLCFT",
            "D100014000000000011984000000000000000 43372078000000045440000014       2117152        45872078       MTH5033H DUSTY PINK L/S FANCY CREW C'MERE CARDIGAN",
            "S1503600000001504300000001504500000001505700000001506500000001506900000001507600000001507900000001509400000001512800000001",
            "S1515100000001518000000001507200000001517300000001    00000000    00000000    00000000    00000000    00000000    00000000",
            "H1453590011234468000000255906040929        00  290 0501030501075966        OPTIONS PLCFT",
            "D100029000000000010120000000000000000 45874751000000040900000029       2117337        45872078       MTH5030H BLK L/S VLVT RIBBON SCOOP C'MERE W/BROOCH",
            "S1501500000001501900000002503700000002353347510001507000000001507800000001509300000001509500000001512900000001514400000001",
            "S1516500000001517000000001517100000001501600000002508900000002513600000001501100000001504600000001509600000001515400000001",
            "S1516200000001516300000001516400000001519200000001517500000001    00000000    00000000    00000000    00000000    00000000",
            "H1453600000004448290908      040929        00  290 0501030501075967        OPTIONS PLCFT",
            "D100014000000000000000029440800000000 45874751000000040900000014       2117347        35874751       MTH5030H BLK L/S VLVT RIBBON SCOOP C'MERE W/BROOCH",
            "S1508300000001513300000001515500000001358447510001516600000001516700000001504900000001513900000001500200000001502700000001",
            "S1503800000001514000000001517400000001518400000001    00000000    00000000    00000000    00000000    00000000    00000000",
            "H1453610011234228000000292210040929        00  290 0501030501075965        OPTIONS PLCFT",
            "D100012000000000010256000000000000000 35874751000000040900000012       2117354        35874751       MTH5030H BLK L/S VLVT RIBBON SCOOP C'MERE W/BROOCH",
            "S1503600000001504300000001504500000001353347510001506900000001507600000001509400000001512800000001515100000001518000000001",
        };

    /**
     * @see TestCase#setUp()
     */
	protected void setUp() throws Exception {
        super.setUp();

        int i;
        Line l;
        Common.setConnectionId(dbIdx);
        poCopyBook = copybookInt.getLayout(poCopybookName);
        poFileRep = new FileView(poCopyBook, LineIOProvider.getInstance(), false);

        for (i = 0; i < textLines.length; i++) {
            l = new Line(poCopyBook, Conversion.getBytes(textLines[i], ""));
            poFileRep.add(l);
        }
    }

    /**
     * replace test 1
     * @throws Exception any error
     */
    public void testReplace1() throws Exception {
        int recId = poCopyBook.getRecordIndex("ams PO Download: Allocation");
        String s;
        boolean ok = true;
   
    	// TODO Fix problems due to using prefered index !!!!
    	// TODO Fix problems due to using prefered index !!!!
    	// TODO Fix problems due to using prefered index !!!!

        FilePosition pos = new FilePosition(0, 0, recId, 2, true, poFileRep.getRowCount());

        poFileRep.replace(find, replace, pos, true, Compare.OP_CONTAINS, false);

        poFileRep.find(find, pos, true,   Compare.OP_CONTAINS, false);
        pos.adjustPosition(find.length(), Compare.OP_CONTAINS);
        poFileRep.find(find, pos, true,   Compare.OP_CONTAINS, false);

        poFileRep.replace(find, replace, pos, true, Compare.OP_CONTAINS, false);

        for (int i = 0; i < result1.length; i++) {
            s = new String(poFileRep.getLine(i).getData());
            if (! result1[i].equals(s)) {
                System.out.println();
                if (ok) {
                	System.out.println("Find: " + find + " Replace: " + replace);
            	}
                System.out.println(i + " >>" + s + "<<");
                System.out.println(i + " >>" + result1[i] + "<<");
                ok = false;
            }
        }
        assertTrue("Problem with Replace test 1", ok);
    }

    /**
     * replace test 1
     * @throws Exception any error
     */
    public void testReplace2() throws Exception {
        int recId = poCopyBook.getRecordIndex("ams PO Download: Allocation");
        String s;
        boolean ok = true;

        FilePosition pos = new FilePosition(0, 0, recId, 2, true, poFileRep.getRowCount());

        poFileRep.replace(find, replace, pos, true, Compare.OP_CONTAINS, false);

        poFileRep.find(find, pos, true, Compare.OP_CONTAINS, false);
        pos.adjustPosition(find.length(), Compare.OP_CONTAINS);

        poFileRep.replace(find, replace, pos, true, Compare.OP_CONTAINS, false);

        for (int i = 0; i < result1.length; i++) {
            s = new String(poFileRep.getLine(i).getData());
            if (! result1[i].equals(s)) {
                System.out.println();
                System.out.println(i + " " + s + "<<");
                System.out.println(i + " " + result1[i] + "<<");
                ok = false;
            }
        }
        assertTrue("Problem with Replace test 2", ok);
    }


    /**
     * replace test 1
     * @throws Exception any error
     */
    public void testReplace2a() throws Exception {
        int recId = poCopyBook.getRecordIndex("ams PO Download: Header");
        String s;
        boolean ok = true;

        FilePosition pos = new FilePosition(0, 0, recId, 2, true, poFileRep.getRowCount());

        poFileRep.replace(find, replace, pos, true, Compare.OP_CONTAINS, false);

        poFileRep.find(find, pos, true, Compare.OP_CONTAINS, false);
        pos.adjustPosition(find.length(), Compare.OP_CONTAINS);

        poFileRep.replace(find, replace, pos, true, Compare.OP_CONTAINS, false);

        for (int i = 0; i < result1.length; i++) {
            s = new String(poFileRep.getLine(i).getData());
            if (! result1[i].equals(s)) {
                System.out.println();
                System.out.println(i + " " + s + "<<");
                System.out.println(i + " " + result1[i] + "<<");
                ok = false;
            }
        }
        assertTrue("Problem with Replace test 2", ok);
    }

    /**
     * replace test 1
     * @throws Exception any error
     */
    public void testReplace3() throws Exception {
        int recId = poCopyBook.getRecordIndex("ams PO Download: Allocation");
        String s;
        boolean ok = true;

        FilePosition pos = new FilePosition(0, 0, recId, 2, true, poFileRep.getRowCount());

        poFileRep.replaceAllImplementation(find, replace, pos, true, Compare.OP_CONTAINS);

         for (int i = 0; i < result2.length; i++) {
            s = new String(poFileRep.getLine(i).getData());
            if (! result2[i].equals(s)) {
                System.out.println();
                System.out.println(i + " " + s + "<<");
                System.out.println(i + " " + result2[i] + "<<");
                ok = false;
            }
        }
        assertTrue("Problem with Replace test 3", ok);
    }
}
