package net.sf.RecordEditor.test.fileStore;

import java.io.IOException;

import net.sf.JRecord.Common.Constants;
import net.sf.JRecord.Details.CharLine;
import net.sf.JRecord.Details.LayoutDetail;
import net.sf.JRecord.Details.Line;
import net.sf.RecordEditor.re.file.FileView;
import net.sf.RecordEditor.utils.fileStorage.DataStoreLarge;
import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
import net.sf.RecordEditor.utils.fileStorage.FileDetails;
import net.sf.RecordEditor.utils.fileStorage.IChunkLine;
import net.sf.RecordEditor.utils.fileStorage.IRecordStore;

public class RunDeleteColFromCsvFile {


	/**
	 * @param recType
	 * @param storageType
	 * @throws IOException
	 */
	private void tstFileView(int recType, int storageType, int size) throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(recType, null);


		FileDetails fd = new FileDetails(layout, storageType, 50, null);

		DataStoreLarge<IChunkLine, IRecordStore> ds = new DataStoreLarge<IChunkLine, IRecordStore>(fd);
		FileView fv = new FileView(ds, null, null);
		fd.setChunkLengthChangeListner(ds);
		
		Line line = new Line(layout);
		int[] trans = {0,2,3};
		DeleteColumnHelper.StdSource lineSource = new DeleteColumnHelper.StdSource(size, 4);
		fv.setLayout(layout);
		lineSource.reset();
		int ii = 0;
		while (lineSource.next()) {
			line.setData(lineSource.toLine());
			fv.add( line.getNewDataLine());
			if (ii % 50000 == 0) {
				if (ii % 2000000 == 0) System.out.println(ii +  "\t");	
				System.out.print('*');
			}
			ii += 1;
		}

		System.out.println("--->" + ii +  "\t");	
		LayoutDetail transLayout = dch.genLayout(recType, trans);
		fv.updateLayout(transLayout, trans);
		System.out.println("<---------------------------------------------------------------------------->" );	
		System.out.println("<---------------------------------------------------------------------------->" );	
	}

	public static void main(String[] args) throws IOException {
		RunDeleteColFromCsvFile r = new RunDeleteColFromCsvFile();
		
		r.tstFileView(Constants.IO_BIN_NAME_1ST_LINE, FileDetails.VARIABLE_LENGTH, 8000000);
	}

}
