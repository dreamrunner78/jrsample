package net.sf.RecordEditor.test.file1;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import net.sf.JRecord.Common.Conversion;
import net.sf.JRecord.Details.AbstractLine;
import net.sf.JRecord.Details.LayoutDetail;
import net.sf.JRecord.Details.Line;
import net.sf.JRecord.External.CobolCopybookLoader;
import net.sf.JRecord.External.CopybookLoader;
import net.sf.JRecord.External.ExternalRecord;
import net.sf.JRecord.External.ToLayoutDetail;
import net.sf.JRecord.Numeric.ICopybookDialects;
import net.sf.RecordEditor.re.file.FileView;

public class TstUpdatingView2 {

	private static final int VIEW_END = 20;

	private static final int VIEW_START = 10;

	private final byte[] schemaLines = 
			( "        01  Rec-20."
			+ "            03 Field-1          Pic x(20).").getBytes();

	private final LayoutDetail schema;
	private final List<AbstractLine> lines = new ArrayList<AbstractLine>(40);

	public TstUpdatingView2() {
		CobolCopybookLoader loaderCBL = new CobolCopybookLoader();
		
		ExternalRecord extlayoutCBL = loaderCBL.loadCopyBook(
			    	    new ByteArrayInputStream(schemaLines),
			    	    Conversion.getCopyBookId("Fixed.cbl"),
			    	    CopybookLoader.SPLIT_NONE, 0, "",
		                ICopybookDialects.FMT_MAINFRAME, 0, null);	
		schema = ToLayoutDetail.getInstance().getLayout(extlayoutCBL);
		for (int i = 0; i < 30; i++) {
			lines.add(new Line(schema, ("Line " + (i+1)).getBytes()));
		}
	}
	
	@Test
	public void testAdd1() {
		tstAdd(true, FileAndView.STD_VIEW);
		tstAdd(true, FileAndView.LARGE_VIEW);
		tstAdd(true, FileAndView.WINDOW_VIEW);
	}
	
	@Test
	public void testAdd2() {
		tstAdd(false, FileAndView.STD_VIEW);
		tstAdd(false, FileAndView.LARGE_VIEW);
		tstAdd(false, FileAndView.WINDOW_VIEW);
	}
	
	
	@Test
	public void testDel1() {
		tstDelete(true, FileAndView.STD_VIEW);
		tstDelete(true, FileAndView.LARGE_VIEW);
		tstDelete(true, FileAndView.WINDOW_VIEW);
	}
	
	@Test
	public void testDel2() {
		tstDelete(false, FileAndView.STD_VIEW);
		tstDelete(false, FileAndView.LARGE_VIEW);
		tstDelete(false, FileAndView.WINDOW_VIEW);
	}
	private void tstAdd(boolean viewFirst, int viewType) {
		FileAndView dtl =  build(viewFirst, viewType);
		
		System.out.println("\n");
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j <= i; j++) {
				dtl.parentFile.insert(null, new Line(schema, ("AddEnd " + (i+1) + "_" + (j+1)).getBytes()), VIEW_END+i);
				checkView("AddEnd " + i + ", " + j + " -> ", dtl);
			}
		}
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j <= i; j++) {
				dtl.parentFile.insert(null, new Line(schema, ("AddStart " + (i+1) + "_" + (j+1)).getBytes()), VIEW_START-i-1);
				checkView("AddStart " + i + ", " + j + " -> ", dtl);
			}
		}
		
		dtl =  build(viewFirst, viewType);
		List<AbstractLine> viewLines = new ArrayList<AbstractLine>(40);
		for (int i = VIEW_START; i < VIEW_END; i++) {
			viewLines.add(lines.get(i));
		}
		int num = viewLines.size();
		
		for (int i = 0; i< 2; i++) {
			Line l = new Line(schema, ("AddView " + i).getBytes());
			viewLines.add(l);
			dtl.viewFile.add(l);
			checkView("ViewAdd1 " + i + " ", dtl, viewLines);
		}
		for (int i = 1; i < 4; i++) {
			for (int j = 0; j <= i; j++) {
				Line l = new Line(schema, ("AddView2 " + 1 + "_" + 1).getBytes());
				viewLines.add(num-i, l);
				dtl.parentFile.insert(null, l, num-i);
				checkView("ViewAdd2 " + i + ", " + j + " -> ", dtl);
				
				l = new Line(schema, ("AddView3 " + 1 + "_" + 1).getBytes());
				viewLines.add(0, l);
				dtl.parentFile.insert(null, l, 0);
				checkView("ViewAdd3 " + i + ", " + j + " -> ", dtl);
			}
		}
	}
	
	private void tstDelete(boolean viewFirst, int viewType) {
		FileAndView dtl =  build(viewFirst, viewType);
		
		System.out.println("\n");
		for (int i = 1; i < 4; i++) {
			dtl.parentFile.deleteLine(VIEW_END);
			checkView("Del " + i + " -> ", dtl);
		}
		for (int i = 1; i < 4; i++) {
				dtl.parentFile.deleteLine(VIEW_START - i);
				checkView("Del " + i + " -> ", dtl);
		}
		
		dtl =  build(viewFirst, viewType);
		
		System.out.println("\n");
		for (int i = 0; i < 3; i++) {
			dtl.parentFile.deleteLine(VIEW_END + i);
			checkView("Del " + i + " -> ", dtl);
		}
		for (int i = 1; i < 4; i++) {
				dtl.parentFile.deleteLine(VIEW_START - i * 2 + 1);
				checkView("Del " + i + " -> ", dtl);
		}
	}
	
	private void checkView(String id, FileAndView dtl) {
		//System.out.print(id + "\t");
		for (int i = VIEW_START; i < VIEW_END; i++) {
			assertEquals(id + (i - VIEW_START), lines.get(i).getFullLine(), dtl.viewFile.getLine(i-VIEW_START).getFullLine());
			assertEquals(id + (i - VIEW_START), lines.get(i).getFullLine(), dtl.viewStore.get(i-VIEW_START).getFullLine());
		}
	}

	private void checkView(String id, FileAndView dtl, List<AbstractLine> viewLines) {
		System.out.print(id + "\t");
		for (int i = 0; i < viewLines.size(); i++) {
			assertEquals(id + (i), viewLines.get(i).getFullLine(), 
					dtl.viewFile.getLine(i).getFullLine());
		}
		assertEquals(viewLines.size(), dtl.viewStore.size());
		assertEquals(viewLines.size(), dtl.viewFile.getRowCount());
		
		for (int i = 0; i < viewLines.size(); i++) {
			assertEquals(id + (i), viewLines.get(i).getFullLine(), 
					dtl.viewStore.get(i).getFullLine());
		}
	}

	
	private FileAndView build(boolean viewFirst, int viewType) {
		int  fileEnd=lines.size();
		FileAndView r = new FileAndView(schema, viewType, VIEW_START, viewFirst ? VIEW_START-1 : VIEW_END-1);
		
		for (int i = 0; i < VIEW_START; i++) {
			r.parentFile.add(lines.get(i));
		}
		
		FileView viewFile = r.viewFile;
		if (viewFirst) {
			addViewRecords(viewFile);
			addEndRecords(fileEnd, r);
		} else {
			addViewRecords(r.parentFile);
			addEndRecords(fileEnd, r);
			
			if (viewType != FileAndView.WINDOW_VIEW) {
				addViewRecords(viewFile);
			}
		}
		
		
		return r;
	}

	/**
	 * @param viewFile
	 */
	private void addViewRecords(FileView viewFile) {
		for (int i = VIEW_START; i < VIEW_END; i++) {
			viewFile.add(lines.get(i));
		}
	}

	/**
	 * @param fileEnd
	 * @param r
	 */
	private void addEndRecords(int fileEnd, FileAndView r) {
		for (int i = VIEW_END; i < fileEnd; i++) {
			r.parentFile.add(lines.get(i));
		}
	}

}
