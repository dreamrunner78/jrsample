package net.sf.RecordEditor.test.csv;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import net.sf.JRecord.Common.Conversion;
import net.sf.RecordEditor.re.util.csv.ColumnDateFormatChk;
import net.sf.RecordEditor.re.util.csv.StdDateFormatStr;

public class TstColumnDateFormatChk {

	private static final String[] MONTHS = {
			"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"	
		};

	@Test
	public void test1() {
		List<StdDateFormatStr> dateFormats = StdDateFormatStr.DATE_FORMATS;
		
		int size = dateFormats.size();//
		for (int i = 1; i < size; i++) {
//		for (int i = 1; i < 2; i++) {
//		for (int i = 29; i < 30; i++) {
//		int i = 11; {
			StdDateFormatStr df = dateFormats.get(i);
			ColumnDateFormatChk chk = new ColumnDateFormatChk();
			List<String> dateList = buildDateList1(df.dateFormatStr.length() == 0 ? df.dateName : df.dateFormatStr);
			
			for (String s : dateList) {
				chk.add(s);
			}
			
			
			List<StdDateFormatStr> possible = chk.getPossibleDateFormats();
			if (possible.size() != 1 || ! df.dateFormatStr.equalsIgnoreCase(possible.get(0).dateFormatStr )) {
				System.out.print(i + "\t" + df.dateFormatStr  
						+ (df.dateFormatStr.length() == 6 ? "\t\t": "\t") + possible.size() + " " + dateList.size());
				
				for (StdDateFormatStr dateF : possible) {
					System.out.print("\t" + dateF.dateFormatStr);
				}
				
				System.out.println();
			}

			assertTrue("Expecting to find date Fomat: " + df.dateName, possible.size()>0);
			assertEquals(df.dateFormatStr, possible.get(0).dateFormatStr);
			assertEquals(df.dateFormatStr, 1, possible.size());
		}
	}

	@Test
	public void test2() {
		List<StdDateFormatStr> dateFormats = StdDateFormatStr.DATE_FORMATS;
		
		int size = dateFormats.size();//
		for (int i = 1; i < size; i++) {
//		for (int i = 1; i < 2; i++) {
//		for (int i = 29; i < 30; i++) {
//		int i = 5; {
			StdDateFormatStr df =dateFormats.get(i);
			ColumnDateFormatChk chk = new ColumnDateFormatChk();
			List<String> dateList = buildDateList2(df.dateFormatStr.length() == 0 ? df.dateName : df.dateFormatStr);
			
			for (String s : dateList) {
				chk.add(s);
			}
			
			
			List<StdDateFormatStr> possible = chk.getPossibleDateFormats();
			if (possible.size() == 0 || ! df.dateFormatStr.equalsIgnoreCase(possible.get(0).dateFormatStr )) {
				System.out.print(i + "\t" + df.dateFormatStr  
						+ (df.dateFormatStr.length() == 6 ? "\t\t": "\t") + possible.size() + " " + dateList.size());
				//System.out.print('\t' + dateList.get(0));
				
				for (StdDateFormatStr dateF : possible) {
					System.out.print("\t" + dateF.dateFormatStr);
				}
				
				System.out.println();
			}
			assertTrue("Expecting to find date Fomat: " + df.dateName, possible.size()>0);
			assertEquals(df.dateFormatStr, possible.get(0).dateFormatStr);
		}
	}

	

	@Test
	public void test3() {
		List<StdDateFormatStr> dateFormats = StdDateFormatStr.DATE_FORMATS;
		
		int size = dateFormats.size();//
		for (int i = 1; i < size; i++) {
//		for (int i = 1; i < 2; i++) {
//		for (int i = 29; i < 30; i++) {
//		int i = 1; {
			StdDateFormatStr df =dateFormats.get(i);
			if (df.sep.length() > 0) {
				ColumnDateFormatChk chk = new ColumnDateFormatChk();
				List<String> dateList = buildDateList3(df.dateFormatStr);
				
				for (String s : dateList) {
					chk.add(s);
				}
				
				
				List<StdDateFormatStr> possible = chk.getPossibleDateFormats();
				if (possible.size() == 0 || ! df.dateFormatStr.equalsIgnoreCase(possible.get(0).dateFormatStr )) {
					System.out.print(i + "\t" + df.dateFormatStr  
							+ (df.dateFormatStr.length() == 6 ? "\t\t": "\t") + possible.size() + " " + dateList.size());
					//System.out.print('\t' + dateList.get(0));
					
					for (StdDateFormatStr dateF : possible) {
						System.out.print("\t" + dateF.dateFormatStr);
					}
					
					System.out.println();
				}
				assertTrue("Expecting to find date Fomat: " + df.dateFormatStr, possible.size()>0);
				assertEquals(df.dateFormatStr, possible.get(0).dateFormatStr);
			}
		}
	}

	
	
	
	@SuppressWarnings("deprecation")
	private List<String> buildDateList1(String dateFormat) {
		boolean isCYYMMDD = "CYYMMDD".equals(dateFormat);
		if (isCYYMMDD) {
			dateFormat = "yyMMdd";
		}
		SimpleDateFormat df =new SimpleDateFormat(dateFormat);
		ArrayList<String> list = new ArrayList<String>(90);
		
		for (int yy = 0; yy < 22; yy+=3) {
			for (int mm = 0; mm < 12; mm += 3) {
				for (int dd = 1; dd < 29; dd += 3) {
					list.add(
							(isCYYMMDD  && yy > 9? "1" : "")
							+ df.format(new Date(90 + yy, mm, dd)));
				}
			}
		}
		
		return list;
	}

	
	@SuppressWarnings("deprecation")
	private List<String> buildDateList2(String dateFormat) {
		boolean isCYYMMDD = "CYYMMDD".equals(dateFormat);
		if (isCYYMMDD) {
			dateFormat = "yyMMdd";
		}
		SimpleDateFormat df =new SimpleDateFormat(dateFormat);
		ArrayList<String> list = new ArrayList<String>(90);
		
		for (int yy = 10; yy < 45; yy+=1) {
			if (yy< 24 || yy > 42) {
				for (int mm = 0; mm < 12; mm += 3) {
					for (int dd = 1; dd < 15; dd += 1) {
						list.add( (isCYYMMDD  && yy > 9 ? "1" : "")
								+ df.format(new Date(90 + yy, mm, dd)));
					}
				}
			}
		}
		
		return list;
	}

	
	private List<String> buildDateList3(String dateFormat) {
		//SimpleDateFormat df =new SimpleDateFormat(dateFormat);
		ArrayList<String> list = new ArrayList<String>(90);
		
		for (int yy = 0; yy < 35; yy+=1) {
			String yyS = Integer.toString(yy);
			String yyyyS = Integer.toString(2000 + yy);
			if (yy< 14 || yy > 32) {
				for (int mm = 1; mm <= 12; mm += 3) {
					String mmS = Integer.toString(mm);
					String mmmS = MONTHS[mm];
					for (int dd = 1; dd < 15; dd += 1) {
						StringBuilder sb = Conversion.replace(dateFormat, "dd", Integer.toString(dd));
						Conversion.replace(sb, "MMM", mmmS);
						Conversion.replace(sb, "MM", mmS);
						Conversion.replace(sb, "yyyy", yyyyS);
						Conversion.replace(sb, "yy", yyS);
						list.add(sb.toString());
					}
				}
			}
		}
		
		return list;
	}

}
