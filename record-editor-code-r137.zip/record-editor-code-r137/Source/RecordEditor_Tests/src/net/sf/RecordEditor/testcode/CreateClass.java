package net.sf.RecordEditor.testcode;

import net.sf.RecordEditor.examples2.USdate8;

public interface CreateClass {
	public abstract USdate8 create();
}
