package net.sf.RecordEditor.test.fileStore;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Arrays;

import org.junit.Test;

import net.sf.JRecord.Common.Constants;
import net.sf.JRecord.Details.AbstractLine;
import net.sf.JRecord.Details.CharLine;
import net.sf.JRecord.Details.LayoutDetail;
import net.sf.JRecord.Details.Line;
import net.sf.RecordEditor.re.file.FileView;
import net.sf.RecordEditor.utils.fileStorage.DataStoreLarge;
import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
import net.sf.RecordEditor.utils.fileStorage.FileChunkBase;
import net.sf.RecordEditor.utils.fileStorage.FileChunkCharLine;
import net.sf.RecordEditor.utils.fileStorage.FileChunkLine;
import net.sf.RecordEditor.utils.fileStorage.FileDetails;
import net.sf.RecordEditor.utils.fileStorage.IChunkLengthChangedListner;
import net.sf.RecordEditor.utils.fileStorage.IChunkLine;
import net.sf.RecordEditor.utils.fileStorage.IDataStore;
import net.sf.RecordEditor.utils.fileStorage.IFileChunk;
import net.sf.RecordEditor.utils.fileStorage.IRecordStore;

public class TstStoreUpdColumn {

	private static int[][] STD_TRANS = {
			{0, 3, 1, 3, 0}, 
			{3, 2, 1, 0}, 
			{3, 2, 1, 0, 0, 1, 2, 3},
			{3, 0},
			{2},
	};
	
	private IChunkLengthChangedListner chgListner = new IChunkLengthChangedListner() {
		@Override public void blockChanged(IFileChunk ch) {
		}
	};
	private LayoutDetail transLayout;

	@Test
	public void testChar() throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(Constants.IO_UNICODE_NAME_1ST_LINE, null);
		FileDetails fd = new FileDetails(layout, FileDetails.CHAR_LINE, 50, chgListner);

		tstFileChunk(
				fd,
				new FileChunkCharLine(fd, 0, 0), 
				new CharLine(layout, ""),
				new DeleteColumnHelper.StdSource(1000, 4),
				Constants.IO_UNICODE_NAME_1ST_LINE);
	}


	@Test
	public void testByte() throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(Constants.IO_BIN_NAME_1ST_LINE, null);
		FileDetails fd = new FileDetails(layout, FileDetails.VARIABLE_LENGTH, 50, chgListner);

		tstFileChunk(
				fd,
				new FileChunkLine(fd, 0, 0), 
				new Line(layout),
				new DeleteColumnHelper.StdSource(1000, 4),
				Constants.IO_BIN_NAME_1ST_LINE);
	}
	
	

	@Test
	public void testStdDsByte() throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(Constants.IO_BIN_NAME_1ST_LINE, null);
//		FileDetails fd = new FileDetails(layout, FileDetails.VARIABLE_LENGTH, 50, chgListner);

		tstDataStore(
				new DataStoreStd.DataStoreStdBinary<Line>(layout), 
				new Line(layout),
				new DeleteColumnHelper.StdSource(1000, 4),
				Constants.IO_BIN_NAME_1ST_LINE);
	}

	@Test
	public void testStdDsChar() throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(Constants.IO_UNICODE_NAME_1ST_LINE, null);
//		FileDetails fd = new FileDetails(layout, FileDetails.VARIABLE_LENGTH, 50, chgListner);

		tstDataStore(
				new DataStoreStd.DataStoreStdTxt<CharLine>(layout), 
				new CharLine(layout, ""),
				new DeleteColumnHelper.StdSource(1000, 4),
				Constants.IO_UNICODE_NAME_1ST_LINE);
	}


	@Test
	public void testLrgDsByte1() throws IOException {
		tstDsByte(Constants.IO_BIN_NAME_1ST_LINE, FileDetails.VARIABLE_LENGTH, 1000);
	}

	

	@Test
	public void testLrgDsChar1() throws IOException {
		tstDsByte(Constants.IO_UNICODE_NAME_1ST_LINE, FileDetails.CHAR_LINE, 1000);

	}

	@Test
	public void testLrgDsByte2() throws IOException {
		tstDsByte(Constants.IO_BIN_NAME_1ST_LINE, FileDetails.VARIABLE_LENGTH, 100000);
	}



	/**
	 * @param fileStructure
	 * @param dsType
	 * @param size
	 * @throws IOException
	 */
	private void tstDsByte(int fileStructure, int dsType, int size) throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(fileStructure, null);
//		FileDetails fd = new FileDetails(layout, FileDetails.VARIABLE_LENGTH, 50, chgListner);

		tstDataStore(
				new DataStoreLarge<IChunkLine, IRecordStore>(layout, dsType, 250), 
				dsType == FileDetails.CHAR_LINE ? new CharLine(layout, "") : new Line(layout),
				new DeleteColumnHelper.StdSource(size, 4),
				fileStructure);
	}




	/**
	 * @param recType
	 * @param storageType
	 * @throws IOException
	 */
	private void tstLargeDsMultiChunks(int recType, int storageType) throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(recType, null);
		FileDetails fd = new FileDetails(layout, storageType, 50, 8000, chgListner);

		DataStoreLarge<IChunkLine, IRecordStore> ds = new DataStoreLarge<IChunkLine, IRecordStore>(fd);
		fd.setChunkLengthChangeListner(ds);
		tstDataStore(
				ds, 
				storageType == FileDetails.CHAR_LINE ? new CharLine(layout, "") : new Line(layout),
				new DeleteColumnHelper.StdSource(100000, 4),
				recType);
	}

	
	@Test
	public void testLrgFvChar1() throws IOException {
		tstFileViewMultiChunks(Constants.IO_UNICODE_NAME_1ST_LINE, FileDetails.CHAR_LINE, 128000, 1000);
	}


	@Test
	public void testLrgFvByte1() throws IOException {
		tstFileViewMultiChunks(Constants.IO_BIN_NAME_1ST_LINE, FileDetails.VARIABLE_LENGTH, 128000, 1000);
	}





	/**
	 * @param recType
	 * @param storageType
	 * @throws IOException
	 */
	private void tstFileViewMultiChunks(int recType, int storageType, int blockSize, int size) throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(recType, null);
		FileDetails fd = new FileDetails(layout, storageType, 50, blockSize, chgListner);

		DataStoreLarge<IChunkLine, IRecordStore> ds = new DataStoreLarge<IChunkLine, IRecordStore>(fd);
		FileView fv = new FileView(ds, null, null);
		fd.setChunkLengthChangeListner(ds);
		tstDataStore(
				fv, 
				storageType == FileDetails.CHAR_LINE ? new CharLine(layout, "") : new Line(layout),
				new DeleteColumnHelper.StdSource(size, 4),
				recType);
	}

	
	@Test
	public void testFvChar1() throws IOException {
		tstFileView(Constants.IO_UNICODE_NAME_1ST_LINE, FileDetails.CHAR_LINE, 1000);
	}


	@Test
	public void testFvByte1() throws IOException {
		tstFileView(Constants.IO_BIN_NAME_1ST_LINE, FileDetails.VARIABLE_LENGTH, 1000);
	}



	/**
	 * @param recType
	 * @param storageType
	 * @throws IOException
	 */
	private void tstFileView(int recType, int storageType, int size) throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
		
		LayoutDetail layout = dch.genLayout(recType, null);


		DataStoreStd<Line> ds = storageType == FileDetails.CHAR_LINE 
				? new DataStoreStd.DataStoreStdTxt<Line>(layout) 
				: new DataStoreStd.DataStoreStdBinary<Line>(layout);
		FileView fv = new FileView(ds, null, null);
		
		tstDataStore(
				fv, 
				storageType == FileDetails.CHAR_LINE ? new CharLine(layout, "") : new Line(layout),
				new DeleteColumnHelper.StdSource(size, 4),
				recType);
	}
	private void tstFileChunk(
			FileDetails fd,
			FileChunkBase<? extends IChunkLine, ? extends IRecordStore> fc, 
			AbstractLine line, DeleteColumnHelper.ILineSource lineSource,
			int fileStructure) throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
//		for (int id = 0; id < 4; id++) {
//			int[] trans = bldTrans(3, id);
		LayoutDetail oldLayout = (LayoutDetail) line.getLayout();
		for (int[] trans : STD_TRANS) {

			LayoutDetail layout = dch.genLayout(fileStructure, trans);
			bldRecordStore(fc, line, lineSource);
			
			fc.update(oldLayout, layout, trans);
			fd.setLayout(layout);
			
			DeleteColumnHelper.ILineSource ls = new DeleteColumnHelper.TransSource(lineSource, trans);
			checkChunk(Arrays.toString(trans), fc, ls, trans);
		}
	}


	/**
	 * @param fc
	 * @param line
	 * @param lineSource
	 */
	private void bldRecordStore(FileChunkBase<? extends IChunkLine, ? extends IRecordStore> fc, AbstractLine line,
			DeleteColumnHelper.ILineSource lineSource) {
		int num = fc.getRecordStore().getRecordCount();
		for (int i = num -1; i>= 0; i--) {
			fc.remove(i);
		}
		lineSource.reset();
		while (lineSource.next()) {
			line.setData(lineSource.toLine());
			fc.add(line);
		}
	}


	/**
	 * @param fc
	 * @param lineSource
	 * @param trans
	 */
	private void checkChunk(String id, FileChunkBase<? extends IChunkLine, ? extends IRecordStore> fc,
			DeleteColumnHelper.ILineSource ls, int[] trans) {
		
		ls.reset();
		int idx1 = 0;
		String message = id + ": ";
		while (ls.next()) {
			IChunkLine line2 = fc.getLine(idx1++);
			assertEquals(message, ls.toLine(), line2.getFullLine());
			System.out.println(line2.getFullLine());
			for (int j = 0; j < ls.fieldCount(); j++) {
				assertEquals(message, ls.field(j), line2.getFieldValue(0, j).asInt());
			}
		}
	}
	
	
	private <L extends AbstractLine>  void tstDataStore(
			IDataStore<L> fc, 
			L line, DeleteColumnHelper.ILineSource lineSource,
			int fileStructure) throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
//		for (int id = 0; id < 4; id++) {
		for (int[] trans : STD_TRANS) {
			String id = Arrays.toString(trans);
			bldDataStore(fc, line, lineSource);
			
			transLayout = dch.genLayout(fileStructure, trans);
			fc.update(transLayout, trans, null);
			
			DeleteColumnHelper.ILineSource ls = new DeleteColumnHelper.TransSource(lineSource, trans);
			checkDS(id + ":", fc, ls, trans);
		}
	}

	/**
	 * @param fc
	 * @param line
	 * @param lineSource
	 */
	private <L extends AbstractLine> void bldDataStore(IDataStore<L> fc, L line,
			DeleteColumnHelper.ILineSource lineSource) {

		fc.clear();
		fc.setLayoutRE(line.getLayout());
		lineSource.reset();
		while (lineSource.next()) {
			line.setData(lineSource.toLine());
			fc.add((L) line.getNewDataLine());
		}
	}

	/**
	 * @param fc
	 * @param lineSource
	 * @param trans
	 */
	private  <L extends AbstractLine> void checkDS(
			String id,
			IDataStore<L> fc,
			DeleteColumnHelper.ILineSource ls, int[] trans) {
		
		ls.reset();
		int idx1 = 0;
		while (ls.next()) {
			L line2 = fc.get(idx1++);
			assertEquals(id, ls.toLine(), line2.getFullLine());
			for (int j = 0; j < ls.fieldCount(); j++) {
				assertEquals(ls.field(j), line2.getFieldValue(0, j).asInt());
			}
		}
	}

	
	
	private  void tstDataStore(
			FileView fv, 
			AbstractLine line, DeleteColumnHelper.ILineSource lineSource,
			int fileStructure) throws IOException {
		DeleteColumnHelper dch = new DeleteColumnHelper();
//		for (int id = 0; id < 4; id++) {
//			int[] trans = bldTrans(3, id);
		for (int[] trans : STD_TRANS) {
			String id = Arrays.toString(trans);
			System.out.println("=== " + id);
			bldDataStore(fv, line, lineSource);
			
			transLayout = dch.genLayout(fileStructure, trans);
			fv.updateLayout(transLayout, trans);
			
			DeleteColumnHelper.ILineSource ls = new DeleteColumnHelper.TransSource(lineSource, trans);
			checkDS(id + ":", fv, ls, trans);
		}
	}
	/**
	 * @param fc
	 * @param line
	 * @param lineSource
	 */
	private <L extends AbstractLine> void bldDataStore(FileView fc, L line,
			DeleteColumnHelper.ILineSource lineSource) {

		fc.clear();
		fc.setLayout(line.getLayout());
		lineSource.reset();
		while (lineSource.next()) {
			line.setData(lineSource.toLine());
			fc.add((L) line.getNewDataLine());
		}
	}

	/**
	 * @param fc
	 * @param lineSource
	 * @param trans
	 */
	private void checkDS(
			String id,
			FileView fc,
			DeleteColumnHelper.ILineSource ls, int[] trans) {
		
		ls.reset();
		int idx1 = 0;
		while (ls.next()) {
			AbstractLine line2 = fc.getLine(idx1++);
			assertEquals(id, ls.toLine(), line2.getFullLine());
			for (int j = 0; j < ls.fieldCount(); j++) {
				assertEquals(ls.field(j), line2.getFieldValue(0, j).asInt());
			}
		}
	}

}
