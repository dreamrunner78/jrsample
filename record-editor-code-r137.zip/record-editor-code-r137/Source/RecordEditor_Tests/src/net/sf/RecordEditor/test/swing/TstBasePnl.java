package net.sf.RecordEditor.test.swing;

import junit.framework.TestCase;

public class TstBasePnl extends TestCase {

	public void testGetClassName() {
	}
}
