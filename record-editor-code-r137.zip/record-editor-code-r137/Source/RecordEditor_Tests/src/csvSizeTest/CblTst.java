package csvSizeTest;

import java.util.regex.Pattern;

import net.sf.JRecord.Common.Conversion;

public class CblTst {
	private static final String COBOL_REGEX = ".*\\s*[0-9]{1,2}\\s+[a-z0-9\\-_]+\\s+pic\\s+[xa9\\-\\+s].*";
//	private static final String COBOL_REGEX = ".*\\s*[0-9]{1,2}\\s+[a-z0-9\\-_]+.*+pic\\s+[xa9\\-\\+s].*";
	private static Pattern cobolPattern;

	public static void check(String lc) {
		boolean b = cobolPattern.matcher(
							Conversion.replace(
									Conversion.replace(lc, "\r", " "), "\n", " "))
						.matches(); 
		System.out.println();
		System.out.println("==> " + b + (lc.length() < 300 ? lc : lc.substring(0, 300)));
	}
	public static void main(String[] args) {
		String s1 = "012345   01 rec.\n"
				  + "345678      03 f1   pic 9(6).";
		
		String s2 = "         01 rec.\n"
				  + "            03 f1   pic 9(6).";
		
		String s3=
				"        01  Redef-File.                                      \n" + 
				"           03  Record-Type                 pic x(4).         \n" + 
				"               88 Header-Record    value '0000'.             \n" + 
				"               88 Detail-Record1   value 'XA01'.             \n" ;
		String s4 =
				"       01  redef-file.                                      \r\n" + 
				"           03  record-type                 pic x(4).         \r\n" + 
				"               88 header-record    value '0000'.             \r\n" + 
				"               88 detail-record1   value 'xa01'.              \n" + 
				"               88 detail-record2   value 'xa01'.              \n" + 
				"               88 trailer-record   value '9999'.             \n" + 
				"           03  the-record                  pic x(44).        \n" + 
				"                                                             \n" + 
				"           03  header-record redefines the-record.           \n" + 
				"               05 group1.                                    \n" + 
				"                   10 filler               pic x(44).        \n" + 
				"                                                                        \n" + 
				"           03  detail-record1 redefines the-record.\n" + 
				"               05 xa00-acct-extention-segment.     \n" + 
				"                 10 xa00-segment-length                  pic s9(4) comp. \n" + 
				"                 10 xa00-account-key.                                   \n" + 
				"                    15 xa00-client-num                   pic 9(4).      \n" + 
				"                    15 xa00-application-num              pic 9(12).     \n" + 
				"                    15 xa00-application-suffix           pic 9(2).      \n" + 
				"                 10 xa00-xa-root-data.                                  \n" + 
				"                    15 filler                            pic x(96).     \n" + 
				"            03  detail-record2 redefines the-record.                    \n" + 
				"                05 xa01-prdt-chng-seg.                                  \n" + 
				"                   10 xa01-segment-length               pic s9(4) comp. \n" + 
				"                   10 xa01-prdt-chng-key.                               \n" + 
				"                      15 xa01-prdt-chng-date           pic s9(7) comp-3.\n" + 
				"                      15 xa01-acct-num                     pic x(19).   \n" + 
				"                   10 xa01-prdt-chng-info.                              \n" + 
				"                      15 xa01-mna-id                  pic s9(5) comp-3. \n" + 
				"                      15 xa01-solicitation-number          pic 9(6).    \n" + 
				"                      15 xa01-reage-os                     pic 9(3).    \n" + 
				"                      15 xa01-serv-fee-os                  pic x(4).    \n" + 
				"                      15 xa01-annual-fee-ovride-reason     pic x(2).    \n" + 
				"                      15 xa01-ol-fee-wav-flag              pic x(1).                         \n" + 
				"                         88 xa01-ol-fee-wav-flag-yes         value 'y'.   \n" + 
				"                         88 xa01-ol-fee-wav-flag-no          value 'n'.   \n" + 
				"                      15 xa01-auto-lmt-incr-allow          pic x(1).      \n" + 
				"                      15 xa01-convert-awards-flag          pic x(1).      \n" + 
				"                      15 xa01-ins-ind                      pic x(1).      \n" + 
				"                      15 xa01-od-prot-ind                  pic x(1).      \n" + 
				"                         88 xa01-od-prot-yes                 value 'y'.   \n" + 
				"                      15 xa01-tsys-prod                    pic x(2).      \n" + 
				"                      15 xa01-client-prod                  pic x(3).      \n" + 
				"                      15 xa01-acq-stgy-cd                  pic x(6).      \n" + 
				"                      15 xa01-stzn-pool-1                  pic x(6).      \n" + 
				"                      15 xa01-stzn-pool-2                  pic x(6).      \n" + 
				"                      15 xa01-waive-nbr-mth-part-fee       pic x(2).      \n" + 
				"                      15 xa01-discl-grp                    pic x(8).      \n" + 
				"                      15 xa01-alt-discl-grp                pic x(8).      \n" + 
				"                      15 xa01-alt-discl-stat               pic x(1).      \n" + 
				"                      15 xa01-rei-scdl-ovr                 pic x(1).      \n" + 
				"                         88 xa01-rei-scdl-ovr-no-eval        value 'o'.   \n" + 
				"                         88 xa01-rei-scdl-ovr-hold           value 'h'.   \n" + 
				"                         88 xa01-rei-scdl-ovr-force          value 'f'.   \n" + 
				"                         88 xa01-rei-scdl-ovr-norm           value 'n'.   \n" + 
				"                         88 xa01-rei-scdl-ovr-rels-hold      value 'r'.   \n" + 
				"                         88 xa01-rei-scdl-ovr-force-pre      value 'p'.   \n" + 
				"                      15 xa01-expiry-date-version          pic x(3).      \n" + 
				"                      15 xa01-crv-os                       pic 9(2).      \n" + 
				"                      15 xa01-tran-reb-os                  pic 9(3).      \n" + 
				"                      15 xa01-trad-rscl-os                 pic 9(5).      \n" + 
				"                      15 xa01-coll-os                      pic 9(3).      \n" + 
				"                      15 xa01-cb-rpt-os                    pic 9(3).      \n" + 
				"                      15 xa01-cit-os                       pic 9(4).      \n" + 
				"                      15 xa01-min-pay-os                   pic 9(4).      \n" + 
				"                      15 xa01-disp-os                      pic 9(2).      \n" + 
				"                      15 filler                            pic x(2).      \n" + 
				"                      15 xa01-cvck-os                      pic 9(2).      \n" + 
				"                      15 xa01-sbal-woff-os                 pic 9(2).      \n" + 
				"                      15 xa01-crbal-ref-os                 pic 9(2).      \n" + 
				"                      15 xa01-skip-pay-os                  pic 9(3).      \n" + 
				"                      15 xa01-misc-proc-os                 pic 9(3).      \n" + 
				"                      15 filler                            pic x(3).      \n" + 
				"                      15 xa01-cred-lmt-os                  pic 9(3).      \n" + 
				"                      15 xa01-reissue-os                   pic 9(3).      \n" + 
				"                      15 xa01-auth-os                   pic 9(3) comp-3.  \n" + 
				"                      15 xa01-amf-reb-os                   pic x(3).      \n" + 
				"                      15 xa01-close-os                     pic 9(2).      \n" + 
				"                      15 xa01-pot-purge-os                 pic 9(2).      \n" + 
				"                      15 xa01-security-os                  pic 9(3).      \n" + 
				"                      15 xa01-alert-os                     pic 9(3).      \n" + 
				"                      15 xa01-stmt-os                      pic 9(4).      \n" + 
				"                      15 xa01-stmt-isrtgrp                 pic 9(3).      \n" + 
				"                      15 xa01-active-award-opt-id          pic x(4).      \n" + 
				"                      15 filler                            pic x(2).      \n" + 
				"                      15 xa01-card-hold-code               pic 9(3).      \n" + 
				"                      15 xa01-billing-cycle                pic 9(2).      \n" + 
				"                      15 filler                            pic x(2).      \n" + 
				"                      15 xa01-sac                          pic 9(4).      \n" + 
				"                      15 xa01-client-addr-dir              pic 9(4).      \n" + 
				"                      15 xa01-ol-waive-mo              pic s9(3) comp-3.  \n" + 
				"                      15 xa01-alt-discl-grp-stop-date  pic s9(7) comp-3.  \n" + 
				"                      15 xa01-alt-discl-grp-start-date pic s9(7) comp-3.  \n" + 
				"                      15 xa01-pur-anlys-os                 pic 9(2).      \n" + 
				"                      15 xa01-prod-upgr-os                 pic 9(4).      \n" + 
				"                      15 xa01-csrw-os                      pic 9(3).      \n" + 
				"                      15 xa01-ptrm-os                      pic 9(4).      \n" + 
				"                      15 xa01-collection-agency            pic x(6).      \n" + 
				"                      15 xa01-expiry-date-os               pic 9(5).      \n" + 
				"                      15 xa01-auto-pay-os                  pic 9(2).      \n" + 
				"                      15 xa01-purge-date               pic s9(7) comp-3.  \n" + 
				"                      15 xa01-pprice-os                    pic 9(4).      \n" + 
				"                      15 xa01-prod-chng-reas               pic x(1).      \n" + 
				"                         88 xa01-prod-chng-reas-never        value ' '.   \n" + 
				"                         88 xa01-prod-chng-reas-reis         value 'r'.   \n" + 
				"                         88 xa01-prod-chng-reas-iface        value 'i'.   \n" + 
				"                         88 xa01-prod-chng-reas-online       value 'o'.   \n" + 
				"                      15 xa01-zero-ytd-fchg-ind            pic x(1).      \n" + 
				"                      15 xa01-prod-chng-save-area.                        \n" + 
				"                         20 xa01-limit-credit              pic s9(11)     \n" + 
				"                             comp-3.                                      \n" + 
				"                         20 xa01-balance-current       pic s9(11)v9(2)    \n" + 
				"                             comp-3.                                      \n" + 
				"                      15 xa01-member-num                   pic x(19).     \n" + 
				"                      15 xa01-profit-max-option            pic x(03).     \n" + 
				"                      15 xa01-chip-card-option             pic x(04).     \n" + 
				"                      15 xa01-card-mgmt-id                 pic x(08).     \n" + 
				"                      15 xa01-card-isrt-id                 pic x(04).     \n" + 
				"                      15 xa01-prod-chng-source             pic x(08).     \n" + 
				"                      15 xa01-tcat-remap-os                pic x(03).     \n" + 
				"                      15 xa01-active-stand-alone-opt-id    pic x(04).     \n" + 
				"                      15 xa01-enhancement-opt-set          pic x(04).     \n" + 
				"                      15 xa01-opt-set-per-item             pic x(04).     \n" + 
				"                      15 xa01-opt-set-acct-fee             pic x(04).     \n" + 
				"                      15 xa01-opt-set-trans-fee            pic x(04).     \n" + 
				"                      15 xa01-opt-set-ann-fee              pic x(04).     \n" + 
				"                      15 xa01-finance-opt-pricing          pic x(01).     \n" + 
				"                      15 xa01-acct-num-to                  pic x(19).     \n" + 
				"                      15 xa01-card-insert-id-alt1          pic 9(4).      \n" + 
				"                      15 xa01-1098-opt-set                 pic x(02).     \n" + 
				"                      15 xa01-fam-card-option              pic x(04).     \n" + 
				"                      15 xa01-assn-product-identifier      pic x(02).     \n" + 
				"                      15 xa01-assn-reward-id-nbr           pic x(06).     \n" + 
				"                      15 xa01-tsys-loyalty-ind             pic x(01).     \n" + 
				"";
		if (cobolPattern == null) {
			cobolPattern = Pattern.compile(COBOL_REGEX, Pattern.CASE_INSENSITIVE);
		}
		check(s1);
		check(s2);
		check(s3);
		check(s4);
	}

}
