package csvSizeTest;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Random;
import java.util.zip.GZIPOutputStream;

public class CreateCsvFile {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		OutputStreamWriter out = new OutputStreamWriter( 
				new GZIPOutputStream(new FileOutputStream("/home/bruce/work/tmp/large.csv.gz"), 256000));
		StringBuilder b = new StringBuilder(200);
		int rowCount = 11;
		String pref = "field";
		Random  r = new Random(123);
		int size = 0;
		
		for (int i= 1; i <= rowCount; i++) {
			out.write(pref + i);
			pref = ",field";
		}
		out.write("\n");
		
		for (int i = 0; i < 1000000; i++) {
			String sep = "";
			b.setLength(0);
			for (int j = 1; j <= rowCount; j++) {
				b.append(sep);
				
				if (j == 1) {
					b.append(r.nextInt(30));
				} else if (j < 4) {
					b.append(r.nextInt());
				} else if (j == 4 || j == 6|| j == 8 || j == 10) {
					b.append(r.nextInt())
					 .append("     1111     ")
					 .append(r.nextInt(30))
					 .append("       5555555        ")
					 .append(r.nextInt(30))
					 .append("     1111     ")
					 .append(r.nextLong());
				} else {
					b.append(r.nextLong());
				}
				sep = ",";
			}
			out.write(b.toString());
			size += b.length() + 1;
			out.write("\n");
		}
		out.close();
		System.out.println("-> " + size);

	}

}
