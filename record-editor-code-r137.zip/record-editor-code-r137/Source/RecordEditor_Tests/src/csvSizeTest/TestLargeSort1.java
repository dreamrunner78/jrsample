package csvSizeTest;

import java.util.Random;

import net.sf.JRecord.Common.Constants;
import net.sf.JRecord.Details.AbstractLine;
import net.sf.JRecord.Details.LayoutDetail;
import net.sf.JRecord.Details.Line;
import net.sf.JRecord.Details.LineCompare;
import net.sf.JRecord.External.RecordEditorXmlLoader;
import net.sf.RecordEditor.utils.fileStorage.DataStoreLarge;
import net.sf.RecordEditor.utils.fileStorage.FileDetails;

public class TestLargeSort1 {
	//private static final int NUMER_OF_LINES = 200000;
	private static String
		xml = "<?xml version=\"1.0\" ?>\n"
			+ "<RECORD RECORDNAME=\"CSV\" COPYBOOK=\"\" DELIMITER=\",\" DESCRIPTION=\"s\"\n"
			+ "	FILESTRUCTURE=\"" + Constants.IO_NAME_1ST_LINE +"\" STYLE=\"0\" RECORDTYPE=\"Delimited\"\n"
			+ "	LIST=\"Y\" QUOTE=\"\" RecSep=\"default\">"
			+ "	<FIELDS>"
			+ "		<FIELD NAME=\"Field1\" POSITION=\"1\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field2\" POSITION=\"2\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field3\" POSITION=\"3\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field4\" POSITION=\"4\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field5\" POSITION=\"5\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field6\" POSITION=\"6\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field7\" POSITION=\"7\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field8\" POSITION=\"8\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field9\" POSITION=\"9\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field10\" POSITION=\"10\" TYPE=\"Char\"/>"
			+ "		<FIELD NAME=\"Field11\" POSITION=\"11\" TYPE=\"Char\"/>"
			+ "	</FIELDS>"
			+ "</RECORD>";

	public static void main(String[] args) throws Exception {

		LayoutDetail layout = (LayoutDetail) RecordEditorXmlLoader.getExternalRecord(xml, "csv").asLayoutDetail();
		
		FileDetails fd = new FileDetails(
				layout, FileDetails.VARIABLE_LENGTH, 500, 2000, 
				1000, 32000, null);
//		DataStoreLarge ds = new DataStoreLarge(
//				layout,
//				FileDetails.VARIABLE_LENGTH,
//				100000);
		DataStoreLarge ds = new DataStoreLarge(fd);
		
		createData(layout, ds, 20000);
		
		
		LineCompare c = new LineCompare(layout, 0, new int[] {2}, new boolean[] {false});
		ds.sort(c);
		
		System.out.println(" ----------------- Done ------------------");

		AbstractLine last, line = ds.getNewLineRE(0);
		int size = ds.size();
		int count = 0;
		for (int i = 1; i < size; i++ ) {
			last = line;
			line = ds.getNewLineRE(i);
			if (c.compare(last, line) > 0) {
				System.out.print("\t* " + i + "> " + last.getField(0, 2) + " < > " + line.getField(0, 2) + '\t');
				
				if (count++ > 4) {
					System.out.println();
					count = 0;
				}
			}
		}
	}

	/**
	 * @param layout
	 * @param ds
	 */
	public static void createData(LayoutDetail layout, DataStoreLarge ds, int numLines) {
		StringBuilder b = new StringBuilder(200);
		int rowCount = 11;
		String pref = "field";
		Random  r = new Random(123);
		int size = 0;
		Line line = new Line(layout);
		
		for (int i = 0; i < numLines; i++) {
			String sep = "";
			b.setLength(0);
			for (int j = 1; j <= rowCount; j++) {
				b.append(sep);
				
				if (j == 1) {
					b.append(r.nextInt(30));
				} else if (j < 4) {
					b.append(r.nextInt());
				} else if (j == 4 || j == 6|| j == 8 || j == 10) {
					b.append(r.nextInt())
					 .append("     1111     ")
					 .append(r.nextInt(30))
					 .append("       5555555        ")
					 .append(r.nextInt(30))
					 .append("     1111     ")
					 .append(r.nextLong());
				} else {
					b.append(r.nextLong());
				}
				sep = ",";
			}
			line.setData(b.toString());
			ds.add(line);
			size += b.length() + 1;
		}

		System.out.println("-> " + size);
	}

}
