package utils.swing.common;

import java.util.List;

import xCommon.XCsvTextItem;
import net.sf.RecordEditor.utils.common.Common;
import net.sf.RecordEditor.utils.params.Parameters;
import net.sf.RecordEditor.utils.swing.common.CsvTextItem;
import junit.framework.TestCase;

public class TstCsvTextItem extends TestCase {

	public void testDefaultDelim() {
		
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getDefaultCsvList(false, false), Common.FIELD_SEPARATOR_LIST.length - 6, 1);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getDefaultCsvList(false, true), Common.FIELD_SEPARATOR_LIST.length, 1);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getDefaultCsvList(true, false), Common.FIELD_SEPARATOR_LIST.length - 6, 0);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getDefaultCsvList(true, true), Common.FIELD_SEPARATOR_LIST.length, 0);
	}


	public void testCsvDelim01() {

		Parameters.setSavePropertyChanges(false);

		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getCsvList(false, false), Common.FIELD_SEPARATOR_LIST.length - 6, 1);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getCsvList(false, true), Common.FIELD_SEPARATOR_LIST.length, 1);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getCsvList(true, false), Common.FIELD_SEPARATOR_LIST.length - 6, 0);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getCsvList(true, true), Common.FIELD_SEPARATOR_LIST.length, 0);
		
		Parameters.setSavePropertyChanges(true);

	}
	

	public void testCsvDelim02() {

		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		
		Parameters.setProperty(Parameters.CSV_DELIMITER_CHARS + ".count", "5");
		
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getCsvList(false, false), 5, 1);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getCsvList(false, true), 5, 1);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getCsvList(true, false), 5, 0);
		XCsvTextItem.checkList(CsvTextItem.DELIMITER.getCsvList(true, true), 5, 0);
		
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		Parameters.setSavePropertyChanges(true);

	}
	
	public void testCsvDelim03() {
		Updates[] listUpdates01 = {
				new Updates(0, "$", "Dollar"),
				new Updates(3, "%", null),
				new Updates(4, "^", "^"),
				new Updates(17, "x'27'", null),
				
		};
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		applyUpdateToParams(Parameters.CSV_DELIMITER_CHARS, listUpdates01);
		
		checkList(CsvTextItem.DELIMITER.getCsvList(false, false), listUpdates01, Common.FIELD_SEPARATOR_LIST.length - 6, 0);
		checkList(CsvTextItem.DELIMITER.getCsvList(false, true), listUpdates01, Common.FIELD_SEPARATOR_LIST.length, 0);
		checkList(CsvTextItem.DELIMITER.getCsvList(true, false), listUpdates01,  Common.FIELD_SEPARATOR_LIST.length - 6, 0);
		checkList(CsvTextItem.DELIMITER.getCsvList(true, true), listUpdates01,  Common.FIELD_SEPARATOR_LIST.length, 0);
		
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		Parameters.setSavePropertyChanges(true);

	}
	
	public void testParamUpdate01() {
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		
		List<CsvTextItem> csvDelimList = CsvTextItem.DELIMITER.getDefaultCsvList(true, true);
		
		csvDelimList.remove(9);
		csvDelimList.remove(8);
		csvDelimList.remove(5);
		csvDelimList.remove(4);
		csvDelimList.remove(3);
		
		CsvTextItem.DELIMITER.updateList(Parameters.getProperties(), csvDelimList);
	
		XCsvTextItem.checkList(csvDelimList, CsvTextItem.DELIMITER.getCsvList(true, true));
		
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		Parameters.setSavePropertyChanges(true);
	}
	
	
	public void testParamUpdate02() {
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		
		List<CsvTextItem> csvDelimList = CsvTextItem.DELIMITER.getDefaultCsvList(true, true);
		
//		new Updates(0, "$", "Dollar"),
//		new Updates(3, "%", null),
//		new Updates(4, "^", "^"),
//		new Updates(17, "x'27'", null),
		csvDelimList.set(2, new CsvTextItem("$", "Dollar"));
		csvDelimList.set(4, new CsvTextItem("%", null));
		csvDelimList.set(5, new CsvTextItem("^", "^"));
		csvDelimList.set(14, new CsvTextItem("x'27'", null));
		
		CsvTextItem.DELIMITER.updateList(Parameters.getProperties(), csvDelimList);;
		
		XCsvTextItem.checkList(csvDelimList, CsvTextItem.DELIMITER.getCsvList(true, true));
		
		
		csvDelimList.remove(9);
		csvDelimList.remove(8);
		csvDelimList.remove(6);
		csvDelimList.remove(4);
		csvDelimList.remove(1);
		
		CsvTextItem.DELIMITER.updateList(Parameters.getProperties(), csvDelimList);;
		
		XCsvTextItem.checkList(csvDelimList, CsvTextItem.DELIMITER.getCsvList(true, true));
		
	
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		Parameters.setSavePropertyChanges(true);
	}
	
	
	public void testParamUpdate03() {
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		
		List<CsvTextItem> csvDelimList = CsvTextItem.DELIMITER.getDefaultCsvList(true, true);
		
		csvDelimList.set(3, new CsvTextItem(csvDelimList.get(3).value, "comma"));
		CsvTextItem.DELIMITER.updateList(Parameters.getProperties(), csvDelimList);;
		
		XCsvTextItem.checkList(csvDelimList, CsvTextItem.DELIMITER.getCsvList(true, true));
		
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		
		csvDelimList = CsvTextItem.DELIMITER.getDefaultCsvList(true, true);
		
		csvDelimList.set(3, new CsvTextItem("*", csvDelimList.get(3).text));
		CsvTextItem.DELIMITER.updateList(Parameters.getProperties(), csvDelimList);;
		
		XCsvTextItem.checkList(csvDelimList, CsvTextItem.DELIMITER.getCsvList(true, true));
		
	
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		Parameters.setSavePropertyChanges(true);

	}
	

	public void testDefaultQuote() {
		
		XCsvTextItem.checkList(CsvTextItem.QUOTE.getDefaultCsvList(true, true),
				Common.QUOTE_VALUES, Common.QUOTE_LIST, 
				Common.QUOTE_LIST.length, 0);

		List<CsvTextItem> expected = CsvTextItem.QUOTE.getDefaultCsvList(true, true);	
		expected.remove(1);
		expected.remove(0);
		
		XCsvTextItem.checkList(expected, CsvTextItem.QUOTE.getDefaultCsvList(false, false));

	}


	public void testCsvQuote01() {

		Parameters.setSavePropertyChanges(false);

		XCsvTextItem.clearParams(Parameters.CSV_QUOTE_CHARS, Common.QUOTE_LIST.length);
		
		XCsvTextItem.checkList(CsvTextItem.QUOTE.getCsvList(true, true), 
				Common.QUOTE_VALUES, Common.QUOTE_LIST, 
				Common.QUOTE_LIST.length, 0);
		

		List<CsvTextItem> expected = CsvTextItem.QUOTE.getDefaultCsvList(true, true);
		
		expected.remove(1);
		expected.remove(0);
		
		XCsvTextItem.checkList(expected, CsvTextItem.QUOTE.getCsvList(false, false));

		
		Parameters.setSavePropertyChanges(true);

	}
	
	public void testQuoteUpdate01() {
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_QUOTE_CHARS, Common.QUOTE_LIST.length);
		
		List<CsvTextItem> csvDelimList = CsvTextItem.QUOTE.getDefaultCsvList(true, true);
		
		csvDelimList.remove(1);
		csvDelimList.remove(3);
		
		CsvTextItem.QUOTE.updateList(Parameters.getProperties(), csvDelimList);;
	
		XCsvTextItem.checkList(csvDelimList, CsvTextItem.QUOTE.getCsvList(true, true));
		
		XCsvTextItem.clearParams(Parameters.CSV_QUOTE_CHARS, Common.QUOTE_LIST.length);
		Parameters.setSavePropertyChanges(true);
	}
	
	
	public void testQuoteUpdate02() {
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_QUOTE_CHARS, Common.QUOTE_LIST.length);
		
		List<CsvTextItem> csvDelimList = CsvTextItem.QUOTE.getDefaultCsvList(true, true);
		
		csvDelimList.set(2, new CsvTextItem(csvDelimList.get(2).value, "Double Quote"));
		csvDelimList.set(3, new CsvTextItem("%", csvDelimList.get(3).getText()));
		csvDelimList.add(new CsvTextItem("*", "Star"));
		
		CsvTextItem.QUOTE.updateList(Parameters.getProperties(), csvDelimList);;
	
		XCsvTextItem.checkList(csvDelimList, CsvTextItem.QUOTE.getCsvList(true, true));
		
		XCsvTextItem.clearParams(Parameters.CSV_QUOTE_CHARS, Common.QUOTE_LIST.length);
		Parameters.setSavePropertyChanges(true);

		
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		
	}


	
	public void testQuoteUpdate03() {
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_QUOTE_CHARS, Common.QUOTE_LIST.length);
		
		List<CsvTextItem> csvDelimList = CsvTextItem.QUOTE.getDefaultCsvList(true, true);
		
		csvDelimList.add(new CsvTextItem("*", "Star"));
		csvDelimList.add(new CsvTextItem("1", "one"));
		csvDelimList.add(new CsvTextItem("2", "two"));
		csvDelimList.add(new CsvTextItem("$", "dollar"));
		
		CsvTextItem.QUOTE.updateList(Parameters.getProperties(), csvDelimList);;
	
		XCsvTextItem.checkList(csvDelimList, CsvTextItem.QUOTE.getCsvList(true, true));
		
		XCsvTextItem.clearParams(Parameters.CSV_QUOTE_CHARS, Common.QUOTE_LIST.length);
		Parameters.setSavePropertyChanges(true);

		
		Parameters.setSavePropertyChanges(false);
		XCsvTextItem.clearParams(Parameters.CSV_DELIMITER_CHARS, Common.FIELD_SEPARATOR_LIST.length);
		
	}



	private void applyUpdateToParams(String id, Updates[] updates) {
		for (Updates u : updates) {
			Parameters.setProperty(id + "." + u.line, u.value);
			Parameters.setProperty(id + "text." + u.line, u.text);
		}
	}

	private void checkList(List<CsvTextItem> csvDelimiterList, Updates[] updates, int length, int diff) {
		String[] values = Common.FIELD_SEPARATOR_LIST_VALUES.clone();
		String[] text = Common.FIELD_SEPARATOR_LIST.clone();
		
		for (Updates u : updates) {
			values[u.line] = u.value;
			text[u.line] = u.getCompareValue();
		}
		
		XCsvTextItem.checkList(csvDelimiterList, values, text, length, diff);
	}


	private static class Updates {
		final int line;
		final String value, text;
		protected Updates(int line, String value, String text) {
			super();
			this.line = line;
			this.value = value;
			this.text = text;
		}
		
		String getCompareValue() {
			return text==null ? value : text;
		}
	}
}
