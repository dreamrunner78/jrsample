package re.utils.csv;

import java.util.List;

import xCommon.XFileData;
import net.sf.JRecord.Common.Conversion;
import net.sf.RecordEditor.utils.fileAnalysis.CsvAnalyser;
import net.sf.RecordEditor.utils.swing.common.CsvTextItem;
import junit.framework.TestCase;

public class TstCsvAnalyser extends TestCase {

	public void testFindDelim01() {
		List<CsvTextItem> delimList = CsvTextItem.DELIMITER.getDefaultCsvList(false, false);
		
		for (CsvTextItem itm : delimList) {
			String[] lines = XFileData.toDelim(XFileData.dtar020Data(), itm.value);
			CsvAnalyser analyser = new CsvAnalyser(lines, lines.length, Conversion.DEFAULT_ASCII_CHARSET, false);
			assertEquals(itm.text, itm.value, analyser.getSeperatorId());
		}
	}

	public void testFindDelim02() {
		List<CsvTextItem> delimList = CsvTextItem.DELIMITER.getDefaultCsvList(false, false);
		
		for (CsvTextItem itm : delimList) {
			if (! "<Space>".equalsIgnoreCase(itm.text)) {
				byte[][] lines = XFileData.toBytes(
										XFileData.toDelim(XFileData.dtar020Data(), itm.value), 
										Conversion.DEFAULT_ASCII_CHARSET);
				CsvAnalyser analyser = new CsvAnalyser(lines, lines.length, Conversion.DEFAULT_ASCII_CHARSET, false);
				assertEquals(itm.text, itm.value, analyser.getSeperatorId());
			}
		}
	}
	
	public void testFindQuote02() {
		int[] cols = {0, 3};
		List<CsvTextItem> quoteList = CsvTextItem.QUOTE.getDefaultCsvList(false, false);
		
		for (CsvTextItem quoteItm : quoteList) {
			byte[][] lines = XFileData.toBytes(
					XFileData.toDelim(
						XFileData.filterAddQuote(
								XFileData.dtar020Data(), cols, quoteItm.value.charAt(0)), 
								"\t"), 
						Conversion.DEFAULT_ASCII_CHARSET);
			CsvAnalyser analyser = new CsvAnalyser(lines, lines.length, Conversion.DEFAULT_ASCII_CHARSET, false);
			assertEquals(quoteItm.text, quoteItm.text, analyser.getQuote());
			
		}
	}
	
	
	public void testFindQuote01() {
		int[] cols = {0, 3};
		List<CsvTextItem> quoteList = CsvTextItem.QUOTE.getDefaultCsvList(false, false);
		
		for (CsvTextItem quoteItm : quoteList) {
			String[] lines = XFileData.toDelim(
						XFileData.filterAddQuote(XFileData.dtar020Data(), cols, quoteItm.value.charAt(0)), 
						"\t");
			CsvAnalyser analyser = new CsvAnalyser(lines, lines.length, Conversion.DEFAULT_ASCII_CHARSET, false);
			assertEquals(quoteItm.text, quoteItm.text, analyser.getQuote());
			
		}
	}

}
