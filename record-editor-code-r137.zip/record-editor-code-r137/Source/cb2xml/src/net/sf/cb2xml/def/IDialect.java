package net.sf.cb2xml.def;


/**
 * For internal use in cb2xml / JRecord do not use this interface.
 * It will change in the future !!!
 * 
 * @author Bruce Martin
 *
 * 
 */
public interface IDialect {

	public abstract NumericDefinition getNumericDefinition();
	
}
