#! /bin/sh

     cd RecordEditor

     ant
