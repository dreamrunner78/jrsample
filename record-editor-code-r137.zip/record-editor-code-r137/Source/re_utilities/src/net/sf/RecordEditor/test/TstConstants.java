/*
 * @Author Bruce Martin
 * Created on 11/11/2005
 *
 * Purpose:
 */
package net.sf.RecordEditor.test;

/**
 * Constants for testing
 *
 * @author Bruce Martin
 *
 */
public final class TstConstants {

    public static final String TEMP_DIRECTORY = "/home/bm/Programs/RecordEdit/Test/";
    public static final int    DB_INDEX       = 0;

    /**
     * tst constants
     */
    private TstConstants() {
        super();
    }

}
