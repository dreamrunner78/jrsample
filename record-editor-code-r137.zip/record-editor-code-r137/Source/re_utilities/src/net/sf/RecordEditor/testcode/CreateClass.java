package net.sf.RecordEditor.testcode;

import net.sf.RecordEditor.examples.USdate8;

public interface CreateClass {
	public abstract USdate8 create();
}
