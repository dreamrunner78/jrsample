package net.sf.RecordEditor.testcode;

import net.sf.RecordEditor.examples.USdate8;

public class xx implements CreateClass {

	/**
	 * @see net.sf.RecordEditor.testcode.CreateClass#create()
	 */
	public USdate8 create() {
		// TODO Auto-generated method stub
		return new USdate8();
	}
}
