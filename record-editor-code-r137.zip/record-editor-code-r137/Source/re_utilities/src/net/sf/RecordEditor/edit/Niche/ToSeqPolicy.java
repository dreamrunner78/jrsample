package net.sf.RecordEditor.edit.Niche;

public class ToSeqPolicy extends TextFormat {
	public ToSeqPolicy() {
		super(TextFormat.NICHE_SEQPOLICY);
	}
}
