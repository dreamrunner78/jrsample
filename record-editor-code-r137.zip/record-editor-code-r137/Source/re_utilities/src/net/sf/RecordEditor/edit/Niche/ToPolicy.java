package net.sf.RecordEditor.edit.Niche;

public class ToPolicy extends TextFormat {
	public ToPolicy() {
		super(TextFormat.NICHE_POLICY);
	}
}
