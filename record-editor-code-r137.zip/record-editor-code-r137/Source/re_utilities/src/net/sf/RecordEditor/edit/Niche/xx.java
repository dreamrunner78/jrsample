package net.sf.RecordEditor.edit.Niche;

public class xx {
	public xx() {
		new net.sf.RecordEditor.edit.Niche.ToPolicy();
		new net.sf.RecordEditor.edit.Niche.ToSeqPolicy();
	}
}
